import "./App.css";
import "./Style.css";
import FoodPage from "./Pages/FoodPage";

function App() {
  return (
    <div>
      <FoodPage />
    </div>
  );
}

export default App;
